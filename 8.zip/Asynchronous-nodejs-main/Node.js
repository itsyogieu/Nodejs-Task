const fs = require('fs').promises;
async function task1() {
  try {
    console.log("Starting Task 1");
    await new Promise((resolve) => setTimeout(resolve, 2000));
    console.log("Task 1 completed");
    return "Result from Task 1";
  } catch (error) {
    console.error("Error in Task 1:", error);
    throw error;
  }
}
async function task2() {
  try {
    console.log("Starting Task 2");
    await new Promise((resolve) => setTimeout(resolve, 3000));
    console.log("Task 2 completed");
    return "Result from Task 2";
  } catch (error) {
    console.error("Error in Task 2:", error);
    throw error;
  }
}
async function main() {
  try {
    console.log("Main function started");
    
  
    const result1 = await task1();
    console.log("Result from Task 1:", result1);
    
    const result2 = await task2();
    console.log("Result from Task 2:", result2);
    
    console.log("All tasks completed successfully");
  } catch (error) {
    console.error("Error in main function:", error);
  }
}


main();

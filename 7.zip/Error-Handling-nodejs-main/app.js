const express = require('express');
const morgan = require('morgan');
const winston = require('winston');
const app = express();
const port = 3000;


app.use(morgan('dev'));


const logger = winston.createLogger({
  level: 'error',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'error.log' })
  ]
});


app.get('/', (req, res) => {
  res.send('Hello World!');
});


app.get('/error', (req, res) => {
  throw new Error('This is a simulated error.');
});


app.use((err, req, res, next) => {
  logger.error({ message: err.message, stack: err.stack });
  res.status(500).json({ error: 'Something went wrong!' });
});


app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});

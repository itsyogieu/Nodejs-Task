const cron = require('node-cron');
const nodemailer = require('nodemailer');
function sendEmail() {
  let transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
      user: 'your_email@gmail.com',
      pass: 'your_password'
    }
  });
  let mailOptions = {
    from: 'your_email@gmail.com',
    to: 'recipient_email@example.com',
    subject: 'Test Email',
    text: 'This is a test email sent using Node.js cron job.'
  };
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log('Error occurred:', error.message);
    } else {
      console.log('Email sent:', info.response);
    }
  });
}
cron.schedule('0 9 * * *', () => {
  console.log('Running cron job...');
  sendEmail();
}, {
  scheduled: true,
  timezone: 'Your/Timezone' 
});

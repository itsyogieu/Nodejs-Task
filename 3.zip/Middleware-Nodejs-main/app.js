const express = require('express');
const app = express();
const port = 3000;
function logRequestDetails(req, res, next) {
    const method = req.method;
    const url = req.url;
    console.log(`Request Method: ${method}, Request URL: ${url}`);
    res.setHeader('X-Custom-Header', 'Middleware was here');

    next(); 
}
app.use(logRequestDetails);

app.get('/', (req, res) => {
    res.send('Hello World!');
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
